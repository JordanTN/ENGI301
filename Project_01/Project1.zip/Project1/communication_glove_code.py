"""
--------------------------------------------------------------------------
Instrument Glove
--------------------------------------------------------------------------
License:   
Copyright 2019 - Eric Voigt
Adapted by Jordan Ngo, 2022

Redistribution and use in source and binary forms, with or without 
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, 
this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, 
this list of conditions and the following disclaimer in the documentation 
and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors 
may be used to endorse or promote products derived from this software without 
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE 
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
--------------------------------------------------------------------------
Modulate sound output with potentiometer input

  - Potentiometer signals connected to AIN0, AIN1, AIN2, AIN3, AIN4
  - USB audio adapter connected to USB1 (P1_5, P1_7, P1_9, P1_11, P1_13, P1_15)

When potentiometers are changed, the audio output will change

--------------------------------------------------------------------------
Background:
  - Analog servo control class demonstration (analog_servo_control.py)
  - PocketBeagle audio driver setup (http://einsteiniumstudios.com/make-your-beaglebone-speak.html)

"""
# ------------------------------------------------------------------------
# Packages
# ------------------------------------------------------------------------

import time
import Adafruit_BBIO.GPIO as GPIO
import os

# ------------------------------------------------------------------------
# Global Variables
# ------------------------------------------------------------------------

debug       = False


class CommunicationGlove():
    """ People Counter """
    button1     = None
    button2     = None
    button3     = None
    button4     = None
    button5     = None

    def __init__(self, update_time = 0.025, button1="P2_2", button2="P2_4", button3="P2_6", button4="P2_8", button5="P2_10"):
        """ Initialize variables and set up display """
        self.D_THUMB     = button1
        self.D_INDEX     = button2
        self.D_MIDDLE    = button3
        self.D_RING      = button4
        self.D_PINKY     = button5
        
        self.update_time = update_time
        
        self._setup()

# ------------------------------------------------------------------------
# Functions
# ------------------------------------------------------------------------

    def _setup(self):
        """set up the hardware components"""
        # Initialize Buttons
        GPIO.setup(self.D_THUMB, GPIO.IN)
        GPIO.setup(self.D_INDEX, GPIO.IN)
        GPIO.setup(self.D_MIDDLE, GPIO.IN)
        GPIO.setup(self.D_RING, GPIO.IN)
        GPIO.setup(self.D_PINKY, GPIO.IN)
    
    # end def
    
    
    def communicate(self):
        #activation finger

        combination = [0, 0, 0, 0, 0]
        
        
        if (GPIO.input(self.D_THUMB) == 0):
            combination[0] = 1
        if (GPIO.input(self.D_INDEX) == 0):
            combination[1] = 1
        if (GPIO.input(self.D_MIDDLE) == 0):
            combination[2] = 1
        if (GPIO.input(self.D_RING) == 0):
            combination[3] = 1
        if (GPIO.input(self.D_PINKY) == 0):
            combination[4] = 1
            

        return combination
    #end def
    

# ------------------------------------------------------------------------
# Main script
# ------------------------------------------------------------------------

if __name__ == '__main__':
    communication_glove=CommunicationGlove()
    print("Communication Glove Testbed Program Start")

    while True:
      
        value = communication_glove.communicate()
        
        msg = ""

        #print digital button signals
        if value == [0, 0, 0, 0, 0]:
            msg = ""
        else:
            for i in range (5):
                if value[i] != 0:
                    msg = "%s%s" % (msg, str(value[i]*(i+1)))
            
        if (debug):
            print(msg)
        else:
            while ((value[0] != 0)):
                value = communication_glove.communicate()
                print("active")
                #2345
                #234
                #23
                #245
                #2
                if (value[1] != 0):
                    if (value[2] != 0):
                        if (value[3] != 0):
                            if (value[4] != 0):
                                #2345
                                print("2345")
                                break
                            #234
                            print("234")
                            break
                        #23
                        print("23")
                        break
                    if (value[3] != 0):
                        if (value[4] != 0):
                            #245
                            print("245")
                            break
                        #24
                        print("24")
                        break
                    #2
                    print("2")
                    break
        
                #345
                #34
                #3
                if (value[2] != 0):
                    if (value[3] != 0):
                        if (value[4] != 0):
                            #345
                            print("345")
                            break
                        #34
                        print("34")
                        break
                    #3
                    print("3")
                    break
        
                #45
                #4
                if (value[3] != 0):
                    if (value[4] != 0):
                        #45
                        print("45")
                        break
                    #4
                    print("4")
                    break
        
            
        
        
        time.sleep(0.025)

    print("Communication Glove Testbed Program Finished")